"use strict";(()=>{var R={SETTINGS:"apc_settings",OPENAI_KEY:"apc_openai_key",GEMINI_KEY:"apc_gemini_key",GROK_KEY:"apc_grok_key"};var N=`## Writing Humanizer

Your task is to transform and humanize any piece of writing, ensuring it is clear, direct, and engaging. The goal is to refine your source text by removing unnecessary words, avoiding marketing cliches, and adopting a natural, conversational tone.

## Guidelines
1. Focus on Clarity - Make your message easy to understand.
2. Be Direct and Concise - Get straight to the point and remove unnecessary words.
3. Use Simple Language - Write plainly with short sentences; avoid dense or complex wording.
4. Avoid Fluff - Stay away from unnecessary adjectives and adverbs.
5. Avoid Marketing Hype - Don't over-promise or use promotional buzzwords.
6. Keep It Real - Be honest; avoid forced friendliness or exaggeration.
7. Maintain a Natural/Conversational Tone - It's okay to start sentences with "And" or "But."
8. Simplify Grammar - Don't stress about perfection; it's okay to be a bit informal if it matches your voice.
9. Avoid AI-Giveaway Phrases - Drop cliches like "dive into," "unleash your potential," "leverage," "streamline," "game-changing."
10. Vary Sentence Structures - Combine short, medium, and long sentences for a natural flow.
11. Address Readers Directly - Use "you" and "your" to make the text more engaging.
12. Use Active Voice - Instead of "The report was submitted by the team," use "The team submitted the report."
13. Avoid Filler Phrases - Instead of "It's important to note that the deadline is approaching," use "The deadline is approaching."
14. Remove Cliches, Jargon, Hashtags, Semicolons, Emojis, and Asterisks - Keep language clean and straightforward.
15. Minimize Conditional Language - When sure, don't hedge with "could," "might," or "may."
16. Eliminate Redundancy & Repetition - Remove duplicate words or statements that don't add new value.
17. Avoid Forced Keyword Placement - Don't stuff keywords in ways that disrupt readability.
18. Avoid Em Dashes - Use colons or commas instead of em dashes.

## Output Requirements
- Return only the rewritten text. No commentary, quotes, markdown fences, or explanations.
- Maintain a single consistent voice throughout.
- Strive for the fewest words needed to convey each idea without losing meaning.`,l={defaultTemplateId:"auto_fix",llmProvider:"openai",openaiModel:"gpt-4.1-mini",geminiModel:"gemini-2.5-flash",grokModel:"grok-3-mini",systemPrompt:N,showPillLabels:!0,language:"en",siteListMode:"all",siteList:[]},g=12e3;function B(n){return n==="openai"||n==="gemini"||n==="grok"}function q(n){return n==="auto_fix"||n==="professional"||n==="custom"||n==="shorten"}function D(n){return n==="all"||n==="allowlist"||n==="blocklist"}function G(n){return n==="en"||n==="de"}async function m(){let e=(await chrome.storage.local.get(R.SETTINGS))[R.SETTINGS]??{},t=e.llmProvider,r=t&&B(t)?t:l.llmProvider,s=e.defaultTemplateId,i=s&&q(s)?s:l.defaultTemplateId,o=e.siteListMode,a=o&&D(o)?o:l.siteListMode;return{defaultTemplateId:i,llmProvider:r,openaiModel:e.openaiModel??l.openaiModel,geminiModel:e.geminiModel??l.geminiModel,grokModel:e.grokModel??l.grokModel,systemPrompt:e.systemPrompt??l.systemPrompt,templateConfigs:e.templateConfigs,templateOrder:Array.isArray(e.templateOrder)?e.templateOrder:void 0,showPillLabels:e.showPillLabels??l.showPillLabels,language:e.language&&G(e.language)?e.language:l.language,siteListMode:a,siteList:Array.isArray(e.siteList)?e.siteList:[...l.siteList]}}function M(n,e){if(n.siteListMode==="all")return!0;let t=e.toLowerCase(),r=n.siteList.some(s=>{let i=s.toLowerCase().trim();if(!i)return!1;if(i.startsWith("*.")){let o=i.slice(2);return t===o||t.endsWith(`.${o}`)}return t===i});return n.siteListMode==="allowlist"?r:!r}var b={REWRITE_REQUEST:"REWRITE_REQUEST",REWRITE_ABORT:"REWRITE_ABORT",OPEN_SETTINGS:"OPEN_SETTINGS",REWRITE_SUCCESS:"REWRITE_SUCCESS",REWRITE_ERROR:"REWRITE_ERROR"};var p=[{id:"auto_fix",label:"Fix",instruction:"Fix all grammar, spelling, and punctuation errors. Improve clarity where the meaning is ambiguous. Keep the original tone, voice, and intent. Do not add new ideas, remove content, or change the level of formality. If the text is already correct, return it unchanged."},{id:"professional",label:"Pro",instruction:"Rewrite in a clear, professional tone suitable for business communication. Be direct and specific. Remove filler words and vague language. Use active voice. Keep sentences short. Maintain the original intent and all key details. Do not sound robotic or overly formal."},{id:"custom",label:"Mine",instruction:"Rewrite the text according to the custom instruction provided by the user. If no custom instruction is set, improve the text for clarity and readability while keeping the original meaning."},{id:"shorten",label:"Trim",instruction:"Cut the text length by at least 40%. Keep every essential fact, action item, and decision. Remove redundancy, qualifiers, and filler. Prefer short sentences. If the text contains a list, keep the list but tighten each item. Do not drop important context."}],U=new Map(p.map(n=>[n.id,n]));function P(n){if(!n||n.length===0)return p;let e=n.map(r=>U.get(r)).filter(r=>r!==void 0),t=p.filter(r=>!n.includes(r.id));return[...e,...t]}var k=`
:host {
  all: initial;
}

*, *::before, *::after {
  box-sizing: border-box;
}

.sento-root {
  --bg: rgba(12, 12, 16, 0.82);
  --bg-2: rgba(18, 18, 24, 0.88);
  --glass-l: #fff;
  --glass-d: #000;
  --rl: 0.3;
  --rd: 2;
  --sat: 150%;
  --text:   rgba(238, 238, 238, 0.96);
  --text-2: rgba(196, 196, 196, 0.82);
  --text-3: rgba(160, 160, 160, 0.68);
  --error:        #ff7070;
  --error-bg:     rgba(255, 80, 80, 0.14);
  --error-border: rgba(255, 110, 110, 0.32);
  --font: system-ui, -apple-system, 'SF Pro Display', 'Segoe UI', sans-serif;
  --ease: cubic-bezier(0.22, 0.61, 0.36, 1);
}

.sento-bubble {
  position: fixed;
  max-width: calc(100vw - 12px);
  color: var(--text);
  font-family: var(--font);
  z-index: 2147483647;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 4px;
  pointer-events: auto;
}

.hidden {
  display: none !important;
}

.quick-grid {
  display: flex;
  gap: 3px;
  padding: 3px;
  border-radius: 20px;
  border: none;
  background: var(--bg);
  backdrop-filter: blur(24px) saturate(var(--sat));
  -webkit-backdrop-filter: blur(24px) saturate(var(--sat));
  box-shadow:
    inset 0 0 0 0.5px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 14%), transparent),
    inset 1.5px 2px 0px -1px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 70%), transparent),
    inset -1.5px -1.5px 0px -1px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 50%), transparent),
    inset -2px -6px 1px -4px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 30%), transparent),
    inset -0.3px -1px 3px 0px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 10%), transparent),
    inset 0px 2px 3px -1px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 15%), transparent),
    0px 2px 6px 0px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 12%), transparent),
    0px 8px 24px 0px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 10%), transparent);
}

.template-square {
  position: relative;
  height: 34px;
  border-radius: 16px;
  border: none;
  background: transparent;
  color: var(--text);
  cursor: pointer;
  padding: 0 8px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: 5px;
  transition: all 200ms var(--ease);
}

.template-square:hover:not(:disabled),
.template-square:focus-visible {
  background-color: color-mix(in srgb, var(--glass-l) 8%, transparent);
  box-shadow:
    inset 0 0 0 0.5px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 10%), transparent),
    inset 1px 1.5px 0px -0.5px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 40%), transparent);
}

.template-square:hover:not(:disabled) .icon-wrap {
  scale: 1.12;
}

.template-square:disabled {
  opacity: 0.38;
  cursor: progress;
}

.template-square.active {
  background-color: color-mix(in srgb, var(--glass-l) 12%, transparent);
  box-shadow:
    inset 0 0 0 0.5px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 12%), transparent),
    inset 1.5px 1px 0px -0.5px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 70%), transparent),
    inset -1px -0.5px 0px -0.5px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 50%), transparent),
    inset -1.5px -4px 1px -3px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 30%), transparent),
    inset -0.5px 1.5px 2px -0.5px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 14%), transparent),
    0px 2px 4px 0px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 6%), transparent);
  animation: tile-select 440ms ease;
}

.template-square.loading {
  animation: tile-loading 1s linear infinite;
}

@keyframes tile-select {
  0% { scale: 1 1; }
  40% { scale: 1.08 0.96; }
  70% { scale: 0.97 1.02; }
  100% { scale: 1 1; }
}

.icon-wrap {
  width: 14px;
  height: 14px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: var(--text-2);
  flex-shrink: 0;
  transition: scale 200ms cubic-bezier(0.5, 0, 0, 1);
}

.template-square.active .icon-wrap {
  color: var(--text);
}

.icon-svg {
  width: 14px;
  height: 14px;
  display: block;
  fill: currentColor;
}

.template-square:has(.tile-label.hidden) {
  width: 34px;
  padding: 0;
}

.tile-label {
  font-size: 9px;
  font-weight: 600;
  letter-spacing: 0.02em;
  color: var(--text-3);
  line-height: 1;
  pointer-events: none;
  white-space: nowrap;
  transition: color 180ms var(--ease);
}

.template-square:hover:not(:disabled) .tile-label,
.template-square.active .tile-label {
  color: var(--text-2);
}

.sr-only {
  position: absolute !important;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;
}

@keyframes tile-loading {
  0% { filter: brightness(1); }
  50% { filter: brightness(1.15); }
  100% { filter: brightness(1); }
}

.status-msg {
  margin: 0;
  width: 340px;
  border-radius: 16px;
  padding: 7px 12px;
  font-size: 11px;
  line-height: 1.45;
  border: none;
  background: var(--bg);
  color: var(--text-3);
  backdrop-filter: blur(24px) saturate(var(--sat));
  -webkit-backdrop-filter: blur(24px) saturate(var(--sat));
  box-shadow:
    inset 0 0 0 0.5px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 14%), transparent),
    inset 1.5px 2px 0px -1px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 50%), transparent),
    inset -0.3px -1px 3px 0px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 10%), transparent),
    0px 4px 12px 0px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 10%), transparent);
}

.status-msg.error {
  background: var(--error-bg);
  border: 0.5px solid var(--error-border);
  color: var(--error);
  box-shadow: 0px 4px 12px 0px rgba(255, 80, 80, 0.12);
}

.status-msg button {
  margin-left: 8px;
  border: none;
  background: none;
  color: inherit;
  cursor: pointer;
  text-decoration: underline;
  font-size: 11px;
}

.preview {
  width: 340px;
  min-height: 80px;
  max-height: 60vh;
  border-radius: 18px;
  border: none;
  background: var(--bg);
  color: var(--text);
  font-family: var(--font);
  font-size: 12px;
  line-height: 1.5;
  padding: 10px 14px;
  resize: vertical;
  outline: none;
  backdrop-filter: blur(24px) saturate(var(--sat));
  -webkit-backdrop-filter: blur(24px) saturate(var(--sat));
  box-shadow:
    inset 0 0 0 0.5px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 14%), transparent),
    inset 1.5px 2px 0px -1px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 50%), transparent),
    inset -1.5px -1.5px 0px -1px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 30%), transparent),
    inset -0.3px -1px 3px 0px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 10%), transparent),
    0px 4px 12px 0px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 10%), transparent);
}

.preview:focus {
  box-shadow:
    inset 0 0 0 0.5px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 20%), transparent),
    inset 1.5px 2px 0px -1px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 70%), transparent),
    inset -1.5px -1.5px 0px -1px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 50%), transparent),
    inset -0.3px -1px 3px 0px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 10%), transparent),
    0px 6px 16px 0px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 12%), transparent);
}

.actions {
  display: flex;
  justify-content: flex-end;
  gap: 6px;
}

.btn-ghost,
.btn-apply {
  border-radius: 14px;
  padding: 6px 14px;
  font-size: 11px;
  font-weight: 600;
  cursor: pointer;
  transition: all 200ms cubic-bezier(1, 0, 0.4, 1);
}

.btn-ghost {
  border: none;
  background: var(--bg);
  color: var(--text-2);
  backdrop-filter: blur(24px) saturate(var(--sat));
  -webkit-backdrop-filter: blur(24px) saturate(var(--sat));
  box-shadow:
    inset 0 0 0 0.5px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 14%), transparent),
    inset 1.5px 2px 0px -1px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 50%), transparent),
    inset -0.3px -1px 3px 0px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 10%), transparent),
    0px 3px 8px 0px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 8%), transparent);
}

.btn-ghost:hover {
  color: var(--text);
  background: var(--bg-2);
  box-shadow:
    inset 0 0 0 0.5px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 18%), transparent),
    inset 1.5px 2px 0px -1px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 70%), transparent),
    inset -0.3px -1px 3px 0px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 10%), transparent),
    0px 4px 12px 0px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 10%), transparent);
}

.btn-apply {
  border: none;
  background: var(--bg-2);
  color: var(--text);
  backdrop-filter: blur(24px) saturate(var(--sat));
  -webkit-backdrop-filter: blur(24px) saturate(var(--sat));
  box-shadow:
    inset 0 0 0 0.5px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 14%), transparent),
    inset 1.5px 1px 0px -0.5px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 70%), transparent),
    inset -1px -0.5px 0px -0.5px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 50%), transparent),
    inset -1.5px -4px 1px -3px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 30%), transparent),
    inset -0.5px 1.5px 2px -0.5px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 14%), transparent),
    0px 3px 8px 0px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 8%), transparent);
}

.btn-apply:hover {
  background: rgba(24, 24, 32, 0.92);
  box-shadow:
    inset 0 0 0 0.5px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 18%), transparent),
    inset 1.5px 1px 0px -0.5px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 80%), transparent),
    inset -1px -0.5px 0px -0.5px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 60%), transparent),
    inset -1.5px -4px 1px -3px color-mix(in srgb, var(--glass-l) calc(var(--rl) * 40%), transparent),
    inset -0.5px 1.5px 2px -0.5px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 14%), transparent),
    0px 4px 12px 0px color-mix(in srgb, var(--glass-d) calc(var(--rd) * 10%), transparent);
}

.hidden-select,
.hidden-trigger,
.close-btn {
  display: none !important;
}
`;var v=class{constructor(e){this.enabledTemplates=p;this.lastRect=null;this.rafId=0;this.interacting=!1;this.interactionUntil=0;this.handleViewportChange=()=>{this.isVisible()&&this.scheduleReposition()};this.handleMouseDown=e=>{let t=e.target;t&&t.closest("button")&&e.preventDefault()};this.handlePointerDown=()=>{this.interacting=!0,this.interactionUntil=Date.now()+1200};this.handlePointerUp=()=>{this.interacting=!1,this.interactionUntil=Date.now()+900};this.handleFocusIn=()=>{this.interacting=!0,this.interactionUntil=Date.now()+1200};this.handleFocusOut=e=>{let t=e.relatedTarget;if(this.containsTarget(t)){this.interactionUntil=Date.now()+900;return}this.interacting=!1,this.interactionUntil=Date.now()+600};this.handlers=e,this.host=document.createElement("div"),this.host.style.position="fixed",this.host.style.left="0",this.host.style.top="0",this.host.style.zIndex="2147483647",this.shadow=this.host.attachShadow({mode:"open"}),this.rebuild(),document.documentElement.appendChild(this.host),window.addEventListener("resize",this.handleViewportChange,{passive:!0}),window.addEventListener("scroll",this.handleViewportChange,{passive:!0,capture:!0}),window.addEventListener("pointerup",this.handlePointerUp,!0),window.addEventListener("pointercancel",this.handlePointerUp,!0)}destroy(){window.removeEventListener("resize",this.handleViewportChange),window.removeEventListener("scroll",this.handleViewportChange,!0),window.removeEventListener("pointerup",this.handlePointerUp,!0),window.removeEventListener("pointercancel",this.handlePointerUp,!0),this.shadow.removeEventListener("mousedown",this.handleMouseDown,!0),this.host.remove()}setEnabledTemplates(e){let t=p.filter(r=>e.includes(r.id));t.length!==0&&(t.length===this.enabledTemplates.length&&t.every((r,s)=>r.id===this.enabledTemplates[s].id)||(this.enabledTemplates=t,this.rebuild()))}setShowLabels(e){for(let t of this.shadow.querySelectorAll(".tile-label"))t.classList.toggle("hidden",!e)}show(e,t){this.lastRect=e,this.refs.bubble.classList.remove("hidden"),this.reposition()}hide(){this.refs.bubble.classList.add("hidden"),this.lastRect=null}containsTarget(e){return e instanceof Node?this.host===e||this.host.contains(e)?!0:this.shadow.contains(e):!1}isVisible(){return!this.refs.bubble.classList.contains("hidden")}isInteracting(){return this.interacting||Date.now()<this.interactionUntil}setLoading(e){this.refs.btnRewrite.disabled=e;let t=this.getTemplateId();for(let r of this.refs.templateButtons)r.disabled=e,r.classList.toggle("loading",e&&r.dataset.templateId===t);this.refs.btnRewrite.textContent=e?"Rewriting\u2026":"Fix"}getTemplateId(){return this.refs.templateSelect.value}setTemplateId(e){!this.enabledTemplates.some(r=>r.id===e)&&this.enabledTemplates.length>0&&(e=this.enabledTemplates[0].id),this.refs.templateSelect.value=e;for(let r of this.refs.templateButtons){let s=r.dataset.templateId===e;s?(r.classList.remove("active"),r.offsetWidth,r.classList.add("active")):r.classList.remove("active"),r.setAttribute("aria-pressed",s?"true":"false")}}setPreview(e){this.refs.preview.classList.remove("hidden"),this.refs.preview.value=e,this.refs.actions.classList.remove("hidden"),this.clearError(),this.reposition()}clearPreview(){this.refs.preview.classList.add("hidden"),this.refs.preview.value="",this.refs.actions.classList.add("hidden")}showError(e,t=!1){this.refs.status.classList.remove("hidden"),this.refs.status.classList.add("error");let r=this.refs.status.querySelector('[data-role="msg"]');r.textContent=e,this.refs.btnSettings.classList.toggle("hidden",!t)}clearError(){this.refs.status.classList.add("hidden"),this.refs.status.classList.remove("error");let e=this.refs.status.querySelector('[data-role="msg"]');e.textContent="",this.refs.btnSettings.classList.add("hidden")}rebuild(){this.shadow.innerHTML=this.render(),this.refs={root:this.shadow.querySelector(".sento-root"),bubble:this.shadow.querySelector(".sento-bubble"),templateSelect:this.shadow.querySelector("#sento-template"),templateButtons:Array.from(this.shadow.querySelectorAll("[data-template-id]")),btnRewrite:this.shadow.querySelector("#sento-rewrite"),btnClose:this.shadow.querySelector("#sento-close"),status:this.shadow.querySelector("#sento-status"),btnSettings:this.shadow.querySelector("#sento-open-settings"),preview:this.shadow.querySelector("#sento-preview"),actions:this.shadow.querySelector("#sento-actions"),btnApply:this.shadow.querySelector("#sento-apply"),btnRetry:this.shadow.querySelector("#sento-retry")},this.wire()}wire(){this.shadow.addEventListener("mousedown",this.handleMouseDown,!0),this.shadow.addEventListener("pointerdown",this.handlePointerDown,!0),this.shadow.addEventListener("focusin",this.handleFocusIn,!0),this.shadow.addEventListener("focusout",this.handleFocusOut,!0);for(let e of this.refs.templateButtons)e.addEventListener("click",t=>{let r=e.dataset.templateId,s=t.shiftKey;this.setTemplateId(r),setTimeout(()=>this.handlers.onRewrite(r,s),460)});this.refs.btnRewrite.addEventListener("click",()=>{this.handlers.onRewrite(this.getTemplateId())}),this.refs.btnApply.addEventListener("click",()=>{this.handlers.onApply(this.refs.preview.value)}),this.refs.btnRetry.addEventListener("click",()=>{this.handlers.onRetry()}),this.refs.btnClose.addEventListener("click",()=>{this.handlers.onClose()}),this.refs.btnSettings.addEventListener("click",()=>{this.handlers.onOpenSettings()})}scheduleReposition(){this.rafId===0&&(this.rafId=requestAnimationFrame(()=>{this.rafId=0,this.reposition()}))}reposition(){if(!this.lastRect)return;let e=8,t=this.lastRect.left+this.lastRect.width/2,r=this.lastRect.bottom+10,s=this.refs.bubble.offsetWidth||200,i=this.refs.bubble.offsetHeight||40,o=Math.min(Math.max(e,t-s/2),window.innerWidth-s-e),a=r;a+i>window.innerHeight-e&&(a=Math.max(e,this.lastRect.top-i-10)),this.refs.bubble.style.left=`${Math.round(o)}px`,this.refs.bubble.style.top=`${Math.round(a)}px`}render(){let e=this.enabledTemplates,t=e.map(i=>`<option value="${i.id}">${i.label}</option>`).join(""),r={auto_fix:'<svg viewBox="0 0 24 24" class="icon-svg" aria-hidden="true"><path d="M12 2.5l1.9 7.1 7.1 1.9-7.1 1.9-1.9 7.1-1.9-7.1-7.1-1.9 7.1-1.9z"/></svg>',professional:'<svg viewBox="0 0 24 24" class="icon-svg" aria-hidden="true"><path d="M10.5 3h3l1 5.5H9.5L10.5 3zm-1.2 7h5.4l-1.5 11h-2.4L9.3 10z"/></svg>',custom:'<svg viewBox="0 0 24 24" class="icon-svg" aria-hidden="true"><circle cx="12" cy="12" r="3"/><circle cx="12" cy="4" r="1.5"/><circle cx="12" cy="20" r="1.5"/><circle cx="4" cy="12" r="1.5"/><circle cx="20" cy="12" r="1.5"/></svg>',shorten:'<svg viewBox="0 0 24 24" class="icon-svg" aria-hidden="true"><path d="M4 6h16v2.5H4zm0 5.5h11v2.5H4zm0 5.5h7v2.5H4z"/></svg>'},s=e.map((i,o)=>`
        <button
          class="template-square${o===0?" active":""}"
          type="button"
          data-template-id="${i.id}"
          aria-label="Rewrite as ${i.label}"
          aria-pressed="${o===0?"true":"false"}"
          title="${i.label}"
        >
          <span class="icon-wrap">${r[i.id]}</span>
          <span class="tile-label">${i.label}</span>
        </button>
      `).join("");return`
      <style>${k}</style>
      <div class="sento-root">
        <div class="sento-bubble hidden">
          <div class="quick-grid" role="toolbar" aria-label="Sent\u014D rewrite templates">
            ${s}
          </div>

          <select id="sento-template" class="hidden-select" aria-hidden="true" tabindex="-1">${t}</select>
          <button id="sento-rewrite" class="hidden-trigger" type="button">Auto-Fix</button>
          <button id="sento-close" class="close-btn" type="button" aria-label="Close">\xD7</button>

          <div id="sento-status" class="status-msg hidden">
            <span data-role="msg"></span>
            <button id="sento-open-settings" class="hidden" type="button">Open Settings</button>
          </div>

          <textarea id="sento-preview" class="preview hidden" aria-label="Rewrite preview"></textarea>

          <div id="sento-actions" class="actions hidden">
            <button id="sento-retry" class="btn-ghost" type="button">Retry</button>
            <button id="sento-apply" class="btn-apply" type="button">Apply</button>
          </div>
        </div>
      </div>
    `}};function d(n){return n instanceof HTMLTextAreaElement}function c(n){return n instanceof HTMLElement&&n.isContentEditable}function A(n){return d(n)||c(n)}function u(n){if(!n)return null;if(n instanceof Element){if(A(n))return n;let e=n.closest('textarea,[contenteditable="true"],[contenteditable=""]');return e&&A(e)?e:null}return n.parentElement?u(n.parentElement):null}var K=new Set(["P","DIV","LI","TR","H1","H2","H3","H4","H5","H6","BLOCKQUOTE","PRE","SECTION","ARTICLE","HEADER","FOOTER","DT","DD","FIGCAPTION"]),W=new Set(["UL","OL"]);function F(n){let e=n.parentElement;for(;e;){if(e.tagName==="LI")return!0;e=e.parentElement}return!1}function I(n,e){if(n.nodeType===Node.TEXT_NODE){let a=n.textContent??"";a&&e.push(a);return}if(n.nodeType!==Node.ELEMENT_NODE)return;let t=n,r=t.tagName;if(r==="BR"){e.push(`
`);return}if(W.has(r)){if(e.length>0){let a=e[e.length-1];a&&!a.endsWith(`
`)&&e.push(`
`)}for(let a of t.childNodes)I(a,e);return}let s=r==="LI",i=K.has(r),o=i&&!s&&F(t);if(i&&!o&&e.length>0){let a=e[e.length-1];a&&!a.endsWith(`
`)&&e.push(`
`)}if(s){if(e.length>0){let a=e[e.length-1];a&&!a.endsWith(`
`)&&e.push(`
`)}e.push("- ")}for(let a of t.childNodes)I(a,e);if(i&&!o&&!s){let a=e[e.length-1];a&&!a.endsWith(`
`)&&e.push(`
`)}}function h(n){let e=n.cloneContents(),t=[];for(let r of e.childNodes)I(r,t);return t.join("").replace(/\n{3,}/g,`

`).trim()}function f(n){return{left:n.left,top:n.top,right:n.right,bottom:n.bottom,width:n.width,height:n.height}}function H(n){let e=n.split(`
`),t=[],r=!1;for(let s of e){let i=s.trim(),o=i.match(/^[-*•]\s+(.*)/);if(o){r||(t.push("<ul>"),r=!0);let a=o[1].replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");t.push(`<li>${a}</li>`)}else if(r&&(t.push("</ul>"),r=!1),!i)t.push("<p></p>");else{let a=i.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");t.push(`<p>${a}</p>`)}}return r&&t.push("</ul>"),t.join("")}function _(n,e,t){let r=new DataTransfer;r.setData("text/plain",e),r.setData("text/html",t);let s=new ClipboardEvent("paste",{bubbles:!0,cancelable:!0,composed:!0,clipboardData:r});return!n.dispatchEvent(s)}function C(n,e){return!e||e.rangeCount===0?!1:n.contains(e.getRangeAt(0).commonAncestorContainer)}function z(n,e){let t=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value");if(t?.set){t.set.call(n,e);return}n.value=e}var x=class{canHandle(e){return d(e)}readSelection(e){if(!d(e))return"";let t=e.selectionStart??0,r=e.selectionEnd??0;return r>t?e.value.slice(t,r):""}replaceSelection(e,t){if(!d(e))return!1;let r=e.selectionStart,s=e.selectionEnd;if(r==null||s==null||s<r)return!1;let i=e.value.slice(0,r)+t+e.value.slice(s);z(e,i);let o=r+t.length;return e.setSelectionRange(o,o),!0}},w=class{canHandle(e){return c(e)}readSelection(e){if(!c(e))return"";let t=window.getSelection();return!C(e,t)||!t||t.rangeCount===0?"":h(t.getRangeAt(0))}replaceSelection(e,t){if(!c(e))return!1;let r=window.getSelection();if(!C(e,r)||!r||r.rangeCount===0)return!1;let s=H(t);return _(e,t,s)}},E=class{canHandle(e){return c(e)}readSelection(e){if(!c(e))return"";let t=window.getSelection();return!t||t.rangeCount===0?"":h(t.getRangeAt(0))}replaceSelection(e,t){if(!c(e))return!1;e.focus();let r=H(t);return _(e,t,r)}};function $(n){return new InputEvent("beforeinput",{bubbles:!0,cancelable:!0,composed:!0,inputType:"insertReplacementText",data:n})}function Y(n){return new InputEvent("input",{bubbles:!0,composed:!0,inputType:"insertReplacementText",data:n})}var y=class{constructor(){this.adapters=[new x,new w],this.fallbackAdapter=new E}apply(e,t){if(!e.element.isConnected)return{ok:!1,message:"Target field is no longer available. Reselect text and try again."};let r=e.element;if(r.focus(),!this.restoreSelection(e))return{ok:!1,message:"Could not restore text selection. Reselect and try again."};let s=e.mode==="contenteditable";if(!s){let a=$(t);if(!r.dispatchEvent(a))return{ok:!1,message:"Editor prevented rewrite insertion."}}let o=this.adapters.find(a=>a.canHandle(r))?.replaceSelection(r,t)??!1;return!o&&this.fallbackAdapter.canHandle(r)&&(o=this.fallbackAdapter.replaceSelection(r,t)),o?(s||(r.dispatchEvent(Y(t)),r.dispatchEvent(new Event("change",{bubbles:!0}))),{ok:!0}):{ok:!1,message:"Unsupported editor implementation. Try selecting again."}}restoreSelection(e){if(e.mode==="text-control")return!d(e.element)||e.start==null||e.end==null?!1:(e.element.setSelectionRange(e.start,e.end),!0);if(!e.range)return!1;let t=window.getSelection();if(!t)return!1;try{return t.removeAllRanges(),t.addRange(e.range.cloneRange()),!0}catch{return!1}}};var S=class{constructor(e){this.activeEditable=null;this.snapshot=null;this.handleFocusIn=e=>{this.activeEditable=u(e.target),this.capture()};this.handleSelectionChange=()=>{this.activeEditable||(this.activeEditable=u(document.activeElement)),this.capture()};this.handleBlur=e=>{if(this.shouldIgnoreBlur(e.relatedTarget))return;let t=e.target;t&&this.activeEditable===t&&(this.activeEditable=null,this.setSnapshot(null))};this.onSnapshotChange=e.onSnapshotChange,this.shouldIgnoreBlur=e.shouldIgnoreBlur??(()=>!1)}start(){document.addEventListener("focusin",this.handleFocusIn,!0),document.addEventListener("selectionchange",this.handleSelectionChange,!0),document.addEventListener("mouseup",this.handleSelectionChange,!0),document.addEventListener("keyup",this.handleSelectionChange,!0),document.addEventListener("blur",this.handleBlur,!0)}stop(){document.removeEventListener("focusin",this.handleFocusIn,!0),document.removeEventListener("selectionchange",this.handleSelectionChange,!0),document.removeEventListener("mouseup",this.handleSelectionChange,!0),document.removeEventListener("keyup",this.handleSelectionChange,!0),document.removeEventListener("blur",this.handleBlur,!0)}getSnapshot(){return this.snapshot}clearSnapshot(){this.setSnapshot(null)}capture(){let e=this.activeEditable??u(document.activeElement);if(!e||!e.isConnected){this.setSnapshot(null);return}if(d(e)){let t=e.selectionStart??0,r=e.selectionEnd??0;if(r<=t){this.setSnapshot(null);return}let s=e.value.slice(t,r);if(!s.trim()){this.setSnapshot(null);return}let i=e.getBoundingClientRect();this.setSnapshot({element:e,text:s,mode:"text-control",start:t,end:r,rect:f(i),timestamp:Date.now()});return}if(c(e)){let t=window.getSelection();if(!t||t.rangeCount===0||t.isCollapsed){this.setSnapshot(null);return}let r=t.getRangeAt(0);if(!e.contains(r.commonAncestorContainer)){this.setSnapshot(null);return}let s=h(r);if(!s.trim()){this.setSnapshot(null);return}let i=r.getBoundingClientRect(),o=e.getBoundingClientRect();this.setSnapshot({element:e,text:s,mode:"contenteditable",range:r.cloneRange(),rect:i.width>0||i.height>0?f(i):f(o),timestamp:Date.now()});return}this.setSnapshot(null)}setSnapshot(e){this.snapshot=e,this.onSnapshotChange(e)}};function L(){return!!(chrome.runtime&&chrome.runtime.id)}var T=class{constructor(){this.snapshot=null;this.pendingRequestId=null;this.loading=!1;this.hasPreview=!1;this.lastTemplateId="auto_fix";this.inputHandler=new y,this.bubble=new v({onRewrite:(e,t)=>{this.handleRewrite(e,t)},onApply:e=>{this.handleApply(e)},onRetry:()=>{this.handleRewrite(this.lastTemplateId)},onClose:()=>{this.abortPending(),this.loading=!1,this.hasPreview=!1,this.bubble.setLoading(!1),this.bubble.clearPreview(),this.bubble.clearError(),this.bubble.hide()},onOpenSettings:()=>{L()&&chrome.runtime.sendMessage({type:b.OPEN_SETTINGS})}}),this.tracker=new S({onSnapshotChange:e=>{this.handleSnapshot(e)},shouldIgnoreBlur:e=>this.bubble.containsTarget(e)||this.bubble.isInteracting()})}async start(){let e=await m();this.applySettings(e),chrome.storage.onChanged.addListener((t,r)=>{if(r!=="local")return;let i=t.apc_settings?.newValue;i&&this.applySettings(i)}),this.tracker.start()}applySettings(e){if(e.templateConfigs||e.defaultTemplateId||e.templateOrder){let t=this.getEnabledIds(e.templateConfigs,e.templateOrder);this.bubble.setEnabledTemplates(t)}e.defaultTemplateId&&(this.lastTemplateId=e.defaultTemplateId,this.bubble.setTemplateId(e.defaultTemplateId)),e.showPillLabels!==void 0&&this.bubble.setShowLabels(e.showPillLabels)}getEnabledIds(e,t){let r=P(t);if(!e)return r.map(i=>i.id);let s=r.filter(i=>e[i.id]?.enabled!==!1).map(i=>i.id);return s.length>0?s:[r[0].id]}handleSnapshot(e){if(e){if(this.loading||this.hasPreview)return;this.snapshot=e,this.hasPreview=!1,this.bubble.clearPreview(),this.bubble.clearError(),this.bubble.show(e.rect,e.text);return}this.bubble.isInteracting()||(this.abortPending(),this.loading=!1,this.hasPreview=!1,this.snapshot=null,this.bubble.setLoading(!1),this.bubble.clearPreview(),this.bubble.clearError(),this.bubble.hide())}async handleRewrite(e,t=!1){if(this.loading)return;let r=this.snapshot;if(!r||!r.element.isConnected){this.bubble.showError("Selection expired. Please reselect text.");return}let s=crypto.randomUUID();this.pendingRequestId=s,this.lastTemplateId=e;let i=r.text;if(!i.trim()){this.bubble.showError("Select text in an editable field first.");return}i.length>g?(i=i.slice(0,g),this.bubble.showError(`Selection truncated to ${g.toLocaleString()} characters for performance.`)):this.bubble.clearError(),this.loading=!0,this.bubble.setLoading(!0);try{if(!L()){this.bubble.showError("Extension was reloaded. Refresh the page.");return}let o=await chrome.runtime.sendMessage({type:b.REWRITE_REQUEST,payload:{requestId:s,text:i,templateId:e,context:{url:location.href,title:document.title}}});if(!o||o.ok!==!0){let a=o?.error?.message??"Rewrite failed.",O=o?.error?.code==="MISSING_KEY";this.bubble.showError(a,O);return}if(t){this.handleApply(o.payload.text);return}this.hasPreview=!0,this.bubble.setPreview(o.payload.text)}catch(o){let a=o instanceof Error?o.message:"Unexpected runtime error.";this.bubble.showError(a)}finally{this.loading=!1,this.pendingRequestId=null,this.bubble.setLoading(!1)}}handleApply(e){let t=this.snapshot;if(!t){this.bubble.showError("Selection expired. Reselect text and retry.");return}let r=this.inputHandler.apply(t,e);if(!r.ok){this.bubble.showError(r.message??"Could not apply rewrite.");return}this.hasPreview=!1,this.snapshot=null,this.tracker.clearSnapshot(),this.bubble.clearPreview(),this.bubble.clearError(),this.bubble.hide()}async abortPending(){this.pendingRequestId&&(L()&&await chrome.runtime.sendMessage({type:b.REWRITE_ABORT,requestId:this.pendingRequestId}).catch(()=>{}),this.pendingRequestId=null)}};async function V(){let n=await m();if(!M(n,location.hostname))return;await new T().start()}V().catch(n=>{console.error("[Sent\u014D] failed to initialize content script",n)});})();
