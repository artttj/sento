"use strict";(()=>{var m={SETTINGS:"apc_settings",OPENAI_KEY:"apc_openai_key",GEMINI_KEY:"apc_gemini_key",GROK_KEY:"apc_grok_key"};var h=`## Writing Humanizer

Your task is to transform and humanize any piece of writing, ensuring it is clear, direct, and engaging. The goal is to refine your source text by removing unnecessary words, avoiding marketing cliches, and adopting a natural, conversational tone.

## Guidelines
1. Focus on Clarity - Make your message easy to understand.
2. Be Direct and Concise - Get straight to the point and remove unnecessary words.
3. Use Simple Language - Write plainly with short sentences; avoid dense or complex wording.
4. Avoid Fluff - Stay away from unnecessary adjectives and adverbs.
5. Avoid Marketing Hype - Don't over-promise or use promotional buzzwords.
6. Keep It Real - Be honest; avoid forced friendliness or exaggeration.
7. Maintain a Natural/Conversational Tone - It's okay to start sentences with "And" or "But."
8. Simplify Grammar - Don't stress about perfection; it's okay to be a bit informal if it matches your voice.
9. Avoid AI-Giveaway Phrases - Drop cliches like "dive into," "unleash your potential," "leverage," "streamline," "game-changing."
10. Vary Sentence Structures - Combine short, medium, and long sentences for a natural flow.
11. Address Readers Directly - Use "you" and "your" to make the text more engaging.
12. Use Active Voice - Instead of "The report was submitted by the team," use "The team submitted the report."
13. Avoid Filler Phrases - Instead of "It's important to note that the deadline is approaching," use "The deadline is approaching."
14. Remove Cliches, Jargon, Hashtags, Semicolons, Emojis, and Asterisks - Keep language clean and straightforward.
15. Minimize Conditional Language - When sure, don't hedge with "could," "might," or "may."
16. Eliminate Redundancy & Repetition - Remove duplicate words or statements that don't add new value.
17. Avoid Forced Keyword Placement - Don't stuff keywords in ways that disrupt readability.
18. Avoid Em Dashes - Use colons or commas instead of em dashes.

## Output Requirements
- Return only the rewritten text. No commentary, quotes, markdown fences, or explanations.
- Maintain a single consistent voice throughout.
- Strive for the fewest words needed to convey each idea without losing meaning.`,o={defaultTemplateId:"auto_fix",llmProvider:"openai",openaiModel:"gpt-4.1-mini",geminiModel:"gemini-2.5-flash",grokModel:"grok-3-mini",systemPrompt:h,showPillLabels:!0,forceInsert:!1,language:"en",siteListMode:"all",siteList:[]};function y(t){return t==="openai"||t==="gemini"||t==="grok"}function w(t){return t==="auto_fix"||t==="professional"||t==="custom"||t==="shorten"}function v(t){return t==="all"||t==="allowlist"||t==="blocklist"}function E(t){return t==="en"||t==="de"}async function u(){let e=(await chrome.storage.local.get(m.SETTINGS))[m.SETTINGS]??{},n=e.llmProvider,d=n&&y(n)?n:o.llmProvider,c=e.defaultTemplateId,r=c&&w(c)?c:o.defaultTemplateId,i=e.siteListMode,s=i&&v(i)?i:o.siteListMode;return{defaultTemplateId:r,llmProvider:d,openaiModel:e.openaiModel??o.openaiModel,geminiModel:e.geminiModel??o.geminiModel,grokModel:e.grokModel??o.grokModel,systemPrompt:e.systemPrompt??o.systemPrompt,templateConfigs:e.templateConfigs,templateOrder:Array.isArray(e.templateOrder)?e.templateOrder:void 0,showPillLabels:e.showPillLabels??o.showPillLabels,forceInsert:e.forceInsert??o.forceInsert,language:e.language&&E(e.language)?e.language:o.language,siteListMode:s,siteList:Array.isArray(e.siteList)?e.siteList:[...o.siteList]}}async function g(t){let e=await u();await chrome.storage.local.set({[m.SETTINGS]:{...e,...t}})}function f(t,e){if(t.siteListMode==="all")return!0;let n=e.toLowerCase(),d=t.siteList.some(c=>{let r=c.toLowerCase().trim();if(!r)return!1;if(r.startsWith("*.")){let i=r.slice(2);return n===i||n.endsWith(`.${i}`)}return n===r});return t.siteListMode==="allowlist"?d:!d}async function L(){let t=document.getElementById("site-name"),e=document.getElementById("btn-toggle"),n=document.getElementById("status-label"),d=document.getElementById("footer-hint");document.getElementById("btn-settings").addEventListener("click",()=>{chrome.runtime.openOptionsPage()});let[r]=await chrome.tabs.query({active:!0,currentWindow:!0}),i="";try{let l=new URL(r?.url??"");(l.protocol==="http:"||l.protocol==="https:")&&(i=l.hostname)}catch{}if(!i){t.textContent="No site",e.disabled=!0,n.textContent="Open a webpage to manage site access";return}t.textContent=i;let s=await u(),a=f(s,i);function p(){e.classList.toggle("blocked",!a),e.setAttribute("aria-label",a?`Block on ${i}`:`Unblock on ${i}`),n.textContent=a?"Active on this site":"Blocked on this site",d.textContent=a?"Click to block":"Click to unblock"}p(),e.addEventListener("click",async()=>{s=await u(),a?(s.siteListMode==="allowlist"?await g({siteList:s.siteList.filter(l=>l!==i)}):await g({siteListMode:"blocklist",siteList:[...new Set([...s.siteList,i])]}),a=!1):(s.siteListMode==="blocklist"?await g({siteList:s.siteList.filter(l=>l!==i)}):s.siteListMode==="allowlist"&&await g({siteList:[...new Set([...s.siteList,i])]}),a=!0),p()})}L().catch(console.error);})();
